<?php 
	
/*
 $Id: iostpay_functions.php VER: 1.0.3443 $
 osCommerce, Open Source E-Commerce Solutions
 http://www.oscommerce.com
 Copyright (c) 2008 osCommerce
 Released under the GNU General Public License
 */
	
    	
/* Ensure the http_build_query is defined */